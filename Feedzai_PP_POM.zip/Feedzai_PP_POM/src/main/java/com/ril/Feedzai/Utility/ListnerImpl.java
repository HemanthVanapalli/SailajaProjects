package com.ril.Feedzai.Utility;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

//Listeners listen to the selenium Script & behave accordingly.It is mainly used for reporting purpose
//Here we are using ITestListener

public class ListnerImpl implements ITestListener


{

	@Override
	public void onTestStart(ITestResult result) //onStart Method is called when any test starts
	{
		System.out.println("===========================================================");
		System.out.println("Test Case Execution Started,Test Name is:\t"+result.getName());
		System.out.println("===========================================================");
		
	}

	@Override
	public void onTestSuccess(ITestResult result) //onTestSuccess method is called on the success of any Test.
	{
		System.out.println("===========================================================");
		System.out.println("Test Case Executed Sucesfully,Test Name is:\t"+result.getName());
		System.out.println("===========================================================");
	}

	@Override
	public void onTestFailure(ITestResult result) //onTestFailure method is called on the failure of any Test.
	{
		System.out.println("===========================================================");
		System.out.println("Test Case Execution Got Failed,Test Name is:\t"+result.getName());
		System.out.println("===========================================================");
		
	}

	@Override
	public void onTestSkipped(ITestResult result)//onTestSkipped method is called on skipped of any Test.
	{
		System.out.println("===========================================================");
		System.out.println("Test Case is Skipped,Test Name is:\t"+result.getName());
		System.out.println("===========================================================");
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result)//method is called each time Test fails but is within success percentage.
	{
	
		
	}

	@Override
	public void onStart(ITestContext context)
	{
	
		
	}

	@Override
	public void onFinish(ITestContext context) 
	{
	
		
	}

	

}
