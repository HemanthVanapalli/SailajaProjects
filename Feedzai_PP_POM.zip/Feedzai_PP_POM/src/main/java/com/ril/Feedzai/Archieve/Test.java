package com.ril.Feedzai.Archieve;

import org.testng.TestNG;

public class Test {
  public static void main(String[] args) {
	TestNG.main(new String[] {"resources/testng.xml"});
}
}
