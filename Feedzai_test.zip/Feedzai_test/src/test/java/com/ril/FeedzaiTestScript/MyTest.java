package com.ril.FeedzaiTestScript;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.ril.Feedzai.BaseClass.FeedzaiTestBaseClass;
import com.ril.Feedzai.Utility.Agent_OTP_PP;
import com.ril.Feedzai.Utility.Agent_Services;
import com.ril.Feedzai.Utility.Database;
import com.ril.Feedzai.Utility.Login_LogOut;
import com.ril.Feedzai.Utility.TakeScreenshot;

public class MyTest extends FeedzaiTestBaseClass {
	
	@Test(description="Pulse Changes-Rule 116",groups = "AgentRule")
	public void AgentAllRule() throws Exception {
	
		//WebDriver driver;
		/*System.setProperty("webdriver.chrome.driver","C:\\Chrome1\\chromedriver.exe");
		driver = new ChromeDriver();
		Thread.sleep(2000);
		driver.get("https://10.130.236.50/pulseviews/management/#apps/reliance/dataconfiguration");
		Thread.sleep(1000); 
		driver.close();  */
		
		
		
		
		//logger1 = extent.createTest("AgentTransaction");
		Login_LogOut.Agent_LogIn(driver,"2000003446","Ascii@369");
		String otp = Agent_OTP_PP.Agent_BillPaymentTrial(driver, "919769956830");
		//String otp = Agent_OTP_PP.Agent_BillPaymentTrial(driver, "917040604636");
		//String otp = Agent_OTP_PP.Agent_BillPaymentTrial(driver,"917040604636");
		driver.findElement(By.xpath(pro.getProperty("Agent_OTP"))).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(pro.getProperty("Agent_EnterOtp"))).sendKeys(otp);
		Thread.sleep(2000);
		logger.info("OTP Entered");
		driver.findElement(By.xpath(pro.getProperty("Agent_EnteredOtp"))).click();
		Thread.sleep(4000);
		logger.info("Welcome to Agent HomePage");
		TakeScreenshot.captuerScreenshot(driver, "Agent HomePage");
		Thread.sleep(3000);
	     Agent_Services.CashDeposit_BCServices();
		String MyData=Agent_Services.CashDeposit_BCServices();
		 System.out.print("Required cash Deposit RRN" +" " + MyData); 
		//Database.GetOtp(); 
		
		

}
}